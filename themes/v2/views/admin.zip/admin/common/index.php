<?php
$this->pageTitle = $this->siteName.'后台欢迎您';
?>
<style type="text/css">
    .page-content{
       background: #F1F3FA;
    }
    </style>
<h3><?=$this->siteName?>后台欢迎您</h3>