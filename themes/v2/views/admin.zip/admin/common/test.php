<div class="page-content-wrapper">
		<div class="" style="min-height:1358px;margin-right: 100px;margin-left: 100px;margin-top: 20px">
			<!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<div class="modal fade" id="portlet-config" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
							<h4 class="modal-title">Modal title</h4>
						</div>
						<div class="modal-body">
							 Widget settings form goes here
						</div>
						<div class="modal-footer">
							<button type="button" class="btn blue">Save changes</button>
							<button type="button" class="btn default" data-dismiss="modal">Close</button>
						</div>
					</div>
					<!-- /.modal-content -->
				</div>
				<!-- /.modal-dialog -->
			</div>
			<!-- /.modal -->
			<!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<!-- BEGIN STYLE CUSTOMIZER -->
			<div class="theme-panel hidden-xs hidden-sm">

				<div class="toggler">
				</div>
				<h3 style="float:right;margin-right: 100px"><a>登录</a> | <a>注册</a></h3>
				<div class="toggler-close">
				</div>
				<div class="theme-options">
					<div class="theme-option">
						<a href=""><span>
						发布帖子 </span></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					</div>
					<div class="theme-option">
						<a href=""><span>
						发布帖子 </span></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					</div>
					<div class="theme-option">
						<a href=""><span>
						发布帖子 </span></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					</div>
					<div class="theme-option">
						<a href=""><span>
						发布帖子 </span></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					</div>
					<div class="theme-option">
						<a href=""><span>
						发布帖子 </span></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					</div>
					<div class="theme-option">
						<a href=""><span>
						发布帖子 </span></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					</div>

				</div>
			</div>
			<!-- END STYLE CUSTOMIZER -->
			<!-- BEGIN PAGE HEADER-->
			<h3 class="page-title" style="margin-left: 20px">
			 犬  舍 <img src="http://fdfs.xmcdn.com/group4/M04/DC/8A/wKgDs1P9u9OCb3UGAAJ-Nvqy1GY836.jpg" style="width: 120px;height: 80px">
			</h3>
			<div class="page-bar">
				<ul class="page-breadcrumb">
					<li>
						<i class="fa fa-home"></i>
						<a href="index.html">犬舍</a>
						<i class="fa fa-angle-right"></i>
					</li>
					<li>
						<a href="#">首页</a>
						<i class="fa fa-angle-right"></i>
					</li>
					<!-- <li>
						<a href="#">FAQ</a>
					</li> -->
				</ul>
				<div class="btn-group pull-right">
											<a href="" class="btn default input-inline">搜索</a>
											</div>
				<div class="page-toolbar">
					<div class="btn-group pull-right">
						<input type="text" class="form-control input-inline input-medium" placeholder="请输入搜索内容">

					</div>


				</div>
			</div>
			<!-- END PAGE HEADER-->
			<div class="row">
				<div class="col-md-12" style="display: inline-flex;">
					<div style="width: 16%;margin-left: 15px">
						<div class="dashboard-stat blue-madison" style="height: 100px">
							<div class="visual">
								<i class="fa fa-comments"></i>
							</div>
							<div style="font-size:20px;margin-top: 20px;color: white">
								首页
							</div>
						</div>
					</div>
					<div style="width: 16%;margin-left: 15px">
						<div class="dashboard-stat red-intense" style="height: 100px">
							<div class="visual">
								<i class="fa fa-comments"></i>
							</div>
							<div style="font-size:20px;margin-top: 20px;color: white">
								狗狗领养
							</div>
						</div>
					</div>
					<div style="width: 16%;margin-left: 15px">
						<div class="dashboard-stat green-haze" style="height: 100px">
							<div class="visual">
								<i class="fa fa-comments"></i>
							</div>
							<div style="font-size:20px;margin-top: 20px;color: white">
								狗狗日记
							</div>
						</div>
					</div>
					<div style="width: 16%;margin-left: 15px">
						<div class="dashboard-stat purple-plum" style="height: 100px">
							<div class="visual">
								<i class="fa fa-comments"></i>
							</div>
							<div style="font-size:20px;margin-top: 20px;color: white">
								Single Dog
							</div>
						</div>
					</div>
					<div style="width: 16%;margin-left: 15px">
						<div class="dashboard-stat blue-madison" style="height: 100px">
							<div class="visual">
								<i class="fa fa-comments"></i>
							</div>
							<div style="font-size:20px;margin-top: 20px;color: white">
								狗狗百科
							</div>
						</div>
					</div>
					<div style="width: 16%;margin-left: 15px">
						<div class="dashboard-stat red-intense" style="height: 100px">
							<div class="visual">
								<i class="fa fa-comments"></i>
							</div>
							<div style="font-size:20px;margin-top: 20px;color: white">
								狗狗用品
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- BEGIN PAGE CONTENT-->
			<div class="row">
				<div class="col-md-6">
			        
			            <div style="width: 100%;height: 360px;background-color: rgb(254,121,132);font-size: 68px;text-align: center">
			            	<a><div style="padding-top:100px;color: white;" >
			            	狗狗领养</div></a>
			            	
			            </div>
	        		</div>
			    <div class="col-md-6">
			        <div class="portlet light bordered" style="height: 360px">
			            <div class="portlet-title">
			                <div class="caption font-red-sunglo">
			                    <span class="caption-subject bold uppercase">最新动态</span>
			                </div>
			            </div>
			            <div class="portlet-body">
			            <div class="tab-content">
						<div id="tab_1" class="tab-pane active">
							<div id="accordion1" class="panel-group">
								<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title">
										<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#accordion1_1">
										1. Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry ? </a>
										</h4>
									</div>
									<div id="accordion1_1" class="panel-collapse collapse ">
										<div class="panel-body">
											 Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
										</div>
									</div>
								</div>
								<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title">
										<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#accordion1_2">
										2. Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry ? </a>
										</h4>
									</div>
									<div id="accordion1_2" class="panel-collapse collapse">
										<div class="panel-body">
											 Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
										</div>
									</div>
								</div>
								<div class="panel panel-success">
									<div class="panel-heading">
										<h4 class="panel-title">
										<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#accordion1_3">
										3. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor ? </a>
										</h4>
									</div>
									<div id="accordion1_3" class="panel-collapse collapse">
										<div class="panel-body">
											 Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
										</div>
									</div>
								</div>
								<div class="panel panel-warning">
									<div class="panel-heading">
										<h4 class="panel-title">
										<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#accordion1_4">
										4. Wolf moon officia aute, non cupidatat skateboard dolor brunch ? </a>
										</h4>
									</div>
									<div id="accordion1_4" class="panel-collapse collapse">
										<div class="panel-body">
											 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
										</div>
									</div>
								</div>
								<div class="panel panel-danger">
									<div class="panel-heading">
										<h4 class="panel-title">
										<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#accordion1_5">
										5. Leggings occaecat craft beer farm-to-table, raw denim aesthetic ? </a>
										</h4>
									</div>
									<div id="accordion1_5" class="panel-collapse collapse">
										<div class="panel-body">
											 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
		        		</div>
			    	</div>
			    </div>
				
			</div>
			<!-- <div class="row"> -->
				<div style="width: 800px;height: 100px;display: inline-flex;vertical-align: middle;">
					<div style="float: left;width: 150px">
						<img src="C:\Users\Administrator\Desktop\1.jpg" style="width: 120px;height: 80px">
					</div>
					<div style="font-size:24px;text-align: center;padding-top:22px;width: 550px">
						<b>哈哈哈哈哈哈哈哈哈哈哈哈哈哈</b>
					</div>
					<div style="width: 200px;padding-top:0px;display: inline-flex;">
						<div style="width: 100px;font-size: 18px;padding-top:28px;">
							<a href="">登录</a> | <a href="">注册</a>
						</div>
						
						<div style="width:100px; height:100px;  border-radius:10px; overflow:hidden;padding-top:10px;">
							<img src="C:\Users\Administrator\Desktop\1.jpg" style="width: 50px;height: 50px">
						</div>
					</div>
				</div>
			<!-- </div> -->
			<!-- END PAGE CONTENT-->
		</div>
	</div>
	